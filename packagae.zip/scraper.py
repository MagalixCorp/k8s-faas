from bs4 import BeautifulSoup
import requests


def main(event, context):
    url = event['data']['url']
    # r = requests.get(url).text
    # return r
    return event

# print(main({"data":{"url":"https://webscraper.io/test-sites/e-commerce/allinone"}},""))