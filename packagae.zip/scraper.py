from bs4 import BeautifulSoup
import requests
import json

def main(event, context):
    # url = event['data']['url']
    # r = requests.get(url).text
    # return r
    # data = json.loads(event['data'])
    return event['data']['url']

# print(main({"data":{"url":"https://webscraper.io/test-sites/e-commerce/allinone"}},""))