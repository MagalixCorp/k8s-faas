from bs4 import BeautifulSoup
import requests


def main(event, context):
    url = event['url']
    r = requests.get(url).text
    return r